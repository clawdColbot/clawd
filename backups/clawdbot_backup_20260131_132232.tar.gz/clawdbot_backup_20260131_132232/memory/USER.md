# USER.md - Sobre mi Humano

- **Name:** Andres
- **What to call them:** Andres
- **Pronouns:** 
- **Timezone:** 
- **Notes:** Prefiere comunicarse en español.

## Context

*(En construcción...)*
